vim.keymap.set("n", "<leader>tb", ":bd!<CR>", { desc = "Run bd! command", noremap = true, silent = true })
